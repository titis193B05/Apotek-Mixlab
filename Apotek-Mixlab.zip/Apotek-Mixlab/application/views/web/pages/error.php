

<div class="main">
    <div class="content">
        <div class="error">		
            <h2>404 Not Found</h2>
            <p>Halaman tidak ditemukan</p>
        </div>  	
        <div class="clear"></div>
    </div>
</div>
<style>
    .error{padding:50px 0px}
    .error h2{color:red;text-align: center;font-size: 50px}
    .error p{color:green;text-align: center;font-size:30px}
</style>