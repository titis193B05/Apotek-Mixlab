

<div class="main">
    <div class="content" style="text-align: center">
        <div class="register_account" style="text-align:center;display:inline-block;float: none">
            <h3>Pesanan anda berhasil</h3>
            <p>Harap siapkan Pembayaran secara Tunai saat Produk Tiba.</p>
           
        </div>  	
        <div class="clear"></div>
    </div>
</div>